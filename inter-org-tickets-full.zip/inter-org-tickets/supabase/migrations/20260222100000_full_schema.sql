-- ============================================================
-- Full production schema: auth integration, orgs, threads,
-- comments, announcements, calendar events, invites, SLA
-- ============================================================

-- ── Organizations ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.organizations (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  logo_url    TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orgs_select_all" ON public.organizations FOR SELECT USING (true);
CREATE POLICY "orgs_insert_auth" ON public.organizations FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "orgs_update_auth" ON public.organizations FOR UPDATE USING (auth.role() = 'authenticated');
CREATE TRIGGER organizations_updated_at
  BEFORE UPDATE ON public.organizations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ── Profiles (extends auth.users) ────────────────────────────
CREATE TABLE IF NOT EXISTS public.profiles (
  id           UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email        TEXT NOT NULL,
  full_name    TEXT,
  avatar_url   TEXT,
  org_id       UUID REFERENCES public.organizations(id) ON DELETE SET NULL,
  role         TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin','user','viewer')),
  status       TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','pending')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_select_all"   ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_auth"  ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own"   ON public.profiles FOR UPDATE USING (auth.uid() = id OR
  EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ── Invites ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.invites (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email       TEXT NOT NULL,
  org_id      UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  role        TEXT NOT NULL DEFAULT 'user',
  invited_by  UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  token       TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
  accepted_at TIMESTAMPTZ,
  expires_at  TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.invites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "invites_select_auth" ON public.invites FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "invites_insert_auth" ON public.invites FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "invites_update_auth" ON public.invites FOR UPDATE USING (auth.role() = 'authenticated');

-- ── Threads (inter-org support tickets) ───────────────────────
CREATE TABLE IF NOT EXISTS public.threads (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id       TEXT UNIQUE, -- human-readable e.g. TH-0042
  title             TEXT NOT NULL,
  description       TEXT,
  status            TEXT NOT NULL DEFAULT 'open'
                      CHECK (status IN ('open','in_progress','resolved','closed')),
  priority          TEXT NOT NULL DEFAULT 'medium'
                      CHECK (priority IN ('low','medium','high','critical')),
  relationship_type TEXT NOT NULL DEFAULT 'client'
                      CHECK (relationship_type IN ('internal','client','vendor','partner')),
  raiser_org_id     UUID REFERENCES public.organizations(id) ON DELETE SET NULL,
  recipient_org_id  UUID REFERENCES public.organizations(id) ON DELETE SET NULL,
  raiser_id         UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  assignee_id       UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  eta_value         TEXT,
  eta_unit          TEXT,
  eta_set_at        TIMESTAMPTZ,
  eta_set_by        UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.threads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "threads_select_all"  ON public.threads FOR SELECT USING (true);
CREATE POLICY "threads_insert_auth" ON public.threads FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "threads_update_auth" ON public.threads FOR UPDATE USING (auth.role() = 'authenticated');
CREATE POLICY "threads_delete_auth" ON public.threads FOR DELETE USING (auth.role() = 'authenticated');
CREATE TRIGGER threads_updated_at
  BEFORE UPDATE ON public.threads
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX IF NOT EXISTS idx_threads_status   ON public.threads(status);
CREATE INDEX IF NOT EXISTS idx_threads_priority ON public.threads(priority);
CREATE INDEX IF NOT EXISTS idx_threads_raiser   ON public.threads(raiser_org_id);
CREATE INDEX IF NOT EXISTS idx_threads_assignee ON public.threads(assignee_id);

-- Auto-assign external_id
CREATE OR REPLACE FUNCTION public.set_thread_external_id()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.external_id IS NULL THEN
    NEW.external_id := 'TH-' || LPAD((
      SELECT COUNT(*) + 1 FROM public.threads
    )::TEXT, 4, '0');
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER threads_set_external_id
  BEFORE INSERT ON public.threads
  FOR EACH ROW EXECUTE FUNCTION public.set_thread_external_id();

-- ── Comments ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.comments (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id    UUID REFERENCES public.threads(id) ON DELETE CASCADE,
  issue_id     UUID REFERENCES public.issues(id) ON DELETE CASCADE,
  author_id    UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  author_name  TEXT,
  author_org   TEXT,
  content      TEXT NOT NULL,
  is_internal  BOOLEAN NOT NULL DEFAULT false,
  reply_to_id  UUID REFERENCES public.comments(id) ON DELETE SET NULL,
  category     TEXT CHECK (category IN ('question','update','solution','escalation')),
  is_edited    BOOLEAN NOT NULL DEFAULT false,
  edited_at    TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT comment_must_have_parent CHECK (thread_id IS NOT NULL OR issue_id IS NOT NULL)
);
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "comments_select_all"  ON public.comments FOR SELECT USING (true);
CREATE POLICY "comments_insert_auth" ON public.comments FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "comments_update_auth" ON public.comments FOR UPDATE USING (
  auth.uid() = author_id OR
  EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);
CREATE POLICY "comments_delete_auth" ON public.comments FOR DELETE USING (
  auth.uid() = author_id OR
  EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);
CREATE INDEX IF NOT EXISTS idx_comments_thread ON public.comments(thread_id);
CREATE INDEX IF NOT EXISTS idx_comments_issue  ON public.comments(issue_id);
CREATE INDEX IF NOT EXISTS idx_comments_reply  ON public.comments(reply_to_id);

-- ── Announcements ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.announcements (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title       TEXT NOT NULL,
  content     TEXT NOT NULL,
  category    TEXT NOT NULL DEFAULT 'other'
                CHECK (category IN ('system','maintenance','feature','security','other')),
  is_important BOOLEAN NOT NULL DEFAULT false,
  author_id   UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  org_id      UUID REFERENCES public.organizations(id) ON DELETE SET NULL,
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ann_select_all"  ON public.announcements FOR SELECT USING (true);
CREATE POLICY "ann_insert_auth" ON public.announcements FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "ann_update_auth" ON public.announcements FOR UPDATE USING (auth.role() = 'authenticated');
CREATE POLICY "ann_delete_auth" ON public.announcements FOR DELETE USING (auth.role() = 'authenticated');
CREATE TRIGGER announcements_updated_at
  BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX IF NOT EXISTS idx_ann_published ON public.announcements(published_at DESC);

-- ── Calendar Events ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.calendar_events (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title       TEXT NOT NULL,
  description TEXT,
  event_type  TEXT NOT NULL DEFAULT 'meeting'
                CHECK (event_type IN ('meeting','maintenance','deadline','reminder','other')),
  priority    TEXT NOT NULL DEFAULT 'medium'
                CHECK (priority IN ('low','medium','high')),
  starts_at   TIMESTAMPTZ NOT NULL,
  ends_at     TIMESTAMPTZ NOT NULL,
  all_day     BOOLEAN NOT NULL DEFAULT false,
  org_id      UUID REFERENCES public.organizations(id) ON DELETE SET NULL,
  created_by  UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  thread_id   UUID REFERENCES public.threads(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cal_select_all"  ON public.calendar_events FOR SELECT USING (true);
CREATE POLICY "cal_insert_auth" ON public.calendar_events FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "cal_update_auth" ON public.calendar_events FOR UPDATE USING (auth.role() = 'authenticated');
CREATE POLICY "cal_delete_auth" ON public.calendar_events FOR DELETE USING (auth.role() = 'authenticated');
CREATE TRIGGER calendar_events_updated_at
  BEFORE UPDATE ON public.calendar_events
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX IF NOT EXISTS idx_cal_starts ON public.calendar_events(starts_at);

-- ── Notifications ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  body        TEXT,
  type        TEXT NOT NULL DEFAULT 'info'
                CHECK (type IN ('info','warning','error','success')),
  entity_type TEXT,
  entity_id   UUID,
  is_read     BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif_select_own"  ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "notif_insert_auth" ON public.notifications FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "notif_update_own"  ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "notif_delete_own"  ON public.notifications FOR DELETE USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_notif_user    ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notif_unread  ON public.notifications(user_id, is_read) WHERE is_read = false;

-- ── SLA Policies ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.sla_policies (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  TEXT NOT NULL,
  description           TEXT,
  org_id                UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  priority              TEXT NOT NULL CHECK (priority IN ('low','medium','high','critical')),
  first_response_hours  INT NOT NULL DEFAULT 24,
  resolution_hours      INT NOT NULL DEFAULT 72,
  is_active             BOOLEAN NOT NULL DEFAULT true,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sla_policies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sla_select_all"  ON public.sla_policies FOR SELECT USING (true);
CREATE POLICY "sla_insert_auth" ON public.sla_policies FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "sla_update_auth" ON public.sla_policies FOR UPDATE USING (auth.role() = 'authenticated');
CREATE TRIGGER sla_updated_at
  BEFORE UPDATE ON public.sla_policies
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ── Seed default SLA policies ─────────────────────────────────
INSERT INTO public.sla_policies (name, priority, first_response_hours, resolution_hours) VALUES
  ('Critical Response', 'critical', 1,  4),
  ('High Priority',     'high',     4,  24),
  ('Standard',          'medium',   8,  72),
  ('Low Priority',      'low',      24, 168)
ON CONFLICT DO NOTHING;

-- ── Seed sample announcements ─────────────────────────────────
INSERT INTO public.announcements (title, content, category, is_important) VALUES
  ('Platform Launch', 'Welcome to OrgThread! Your inter-organization ticketing platform is live.', 'feature', true),
  ('Scheduled Maintenance', 'The system will undergo maintenance on the first Sunday of each month from 2–4 AM UTC.', 'maintenance', false),
  ('Security Best Practices', 'Reminder: never share your login credentials. Enable 2FA in account settings.', 'security', true)
ON CONFLICT DO NOTHING;
