import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";

import AuthPage from "./pages/AuthPage";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ThreadsPage from "./pages/ThreadsPage";
import CreateTicketPage from "./pages/CreateTicketPage";
import GroupsPage from "./pages/GroupsPage";
import ChannelsPage from "./pages/ChannelsPage";
import CalendarPage from "./pages/CalendarPage";
import AnnouncementsPage from "./pages/AnnouncementsPage";
import AnomalyDetectionPage from "./pages/AnomalyDetectionPage";
import UserManagementPage from "./pages/UserManagementPage";
import ReportsPage from "./pages/ReportsPage";
import ProjectsPage from "./pages/ProjectsPage";
import KanbanBoardPage from "./pages/KanbanBoardPage";
import IssuesPage from "./pages/IssuesPage";
import AIRoutingPage from "./pages/features/AIRoutingPage";
import SLAManagementPage from "./pages/features/SLAManagementPage";
import OmnichannelPage from "./pages/features/OmnichannelPage";
import CollaborativePage from "./pages/features/CollaborativePage";
import ResourcesPage from "./pages/features/ResourcesPage";
import AdvancedAnalyticsPage from "./pages/features/AdvancedAnalyticsPage";
import WorkflowStudioPage from "./pages/features/WorkflowStudioPage";
import FieldServicePage from "./pages/features/FieldServicePage";
import IntegrationsPage from "./pages/features/IntegrationsPage";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, retry: 1 },
  },
});

const P = ({ children }: { children: React.ReactNode }) => (
  <ProtectedRoute>{children}</ProtectedRoute>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Public */}
            <Route path="/auth" element={<AuthPage />} />

            {/* Protected */}
            <Route path="/"                           element={<P><ThreadsPage /></P>} />
            <Route path="/threads"                    element={<P><ThreadsPage /></P>} />
            <Route path="/create-ticket"              element={<P><CreateTicketPage /></P>} />
            <Route path="/groups"                     element={<P><GroupsPage /></P>} />
            <Route path="/channels"                   element={<P><ChannelsPage /></P>} />
            <Route path="/calendar"                   element={<P><CalendarPage /></P>} />
            <Route path="/announcements"              element={<P><AnnouncementsPage /></P>} />
            <Route path="/anomaly-detection"          element={<P><AnomalyDetectionPage /></P>} />
            <Route path="/user-management"            element={<P><UserManagementPage /></P>} />
            <Route path="/reports"                    element={<P><ReportsPage /></P>} />
            <Route path="/projects"                   element={<P><ProjectsPage /></P>} />
            <Route path="/projects/:projectKey/board" element={<P><KanbanBoardPage /></P>} />
            <Route path="/projects/:projectKey/issues" element={<P><IssuesPage /></P>} />
            <Route path="/analytics"                  element={<P><AdvancedAnalyticsPage /></P>} />
            <Route path="/ai-routing"                 element={<P><AIRoutingPage /></P>} />
            <Route path="/sla-management"             element={<P><SLAManagementPage /></P>} />
            <Route path="/omnichannel"                element={<P><OmnichannelPage /></P>} />
            <Route path="/collaborative"              element={<P><CollaborativePage /></P>} />
            <Route path="/resources"                  element={<P><ResourcesPage /></P>} />
            <Route path="/workflow"                   element={<P><WorkflowStudioPage /></P>} />
            <Route path="/field-service"              element={<P><FieldServicePage /></P>} />
            <Route path="/integrations"               element={<P><IntegrationsPage /></P>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
