import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, BarChart3, Users, Loader2, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { useProjects } from "@/hooks/useProjects";
import { useToast } from "@/hooks/use-toast";

const ProjectsPage = () => {
  const { projects, loading, error, create } = useProjects();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", key: "", description: "" });
  const [submitting, setSubmitting] = useState(false);

  const filtered = projects.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.key.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.key) return;
    setSubmitting(true);
    try {
      await create({ name: form.name, key: form.key.toUpperCase(), description: form.description });
      setOpen(false);
      setForm({ name: "", key: "", description: "" });
    } catch { /* toast handled in hook */ }
    finally { setSubmitting(false); }
  };

  const pct = (p: typeof projects[0]) =>
    p.issue_count ? Math.round(((p.completed_count ?? 0) / p.issue_count) * 100) : 0;

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Projects</h1>
            <p className="text-gray-600">Manage your projects and track progress</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" />New Project</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Create Project</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <div>
                  <label className="text-sm font-medium">Project Name *</label>
                  <Input className="mt-1" placeholder="Mobile App" value={form.name}
                    onChange={e => setForm(f => ({...f, name: e.target.value}))} required />
                </div>
                <div>
                  <label className="text-sm font-medium">Key *</label>
                  <Input className="mt-1" placeholder="MOBILE" value={form.key}
                    onChange={e => setForm(f => ({...f, key: e.target.value.toUpperCase()}))} required maxLength={6} />
                  <p className="text-xs text-gray-500 mt-1">Short identifier used in issue IDs (e.g. MOBILE-001)</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Textarea className="mt-1" placeholder="What is this project about?" value={form.description}
                    onChange={e => setForm(f => ({...f, description: e.target.value}))} />
                </div>
                <Button type="submit" className="w-full" disabled={submitting}>
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create Project"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input placeholder="Search projects..." value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)} className="pl-10" />
        </div>

        {loading && <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-gray-400" /></div>}
        {error && <p className="text-red-500">{error}</p>}

        {!loading && filtered.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <p className="text-lg font-medium mb-2">No projects yet</p>
            <p className="text-sm">Create your first project to get started</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(project => (
            <Card key={project.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <span className="font-bold text-primary text-xs">{project.key}</span>
                  </div>
                  <div>
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <Badge variant="outline" className="mt-1 text-xs">Software</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {project.description && (
                  <CardDescription className="line-clamp-2">{project.description}</CardDescription>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{pct(project)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${pct(project)}%` }} />
                  </div>
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>{project.issue_count ?? 0} issues</span>
                    <span>{project.completed_count ?? 0} done</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button asChild size="sm" className="flex-1">
                    <Link to={`/projects/${project.key}/board`}>
                      <BarChart3 className="h-4 w-4 mr-1" />Board
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="sm" className="flex-1">
                    <Link to={`/projects/${project.key}/issues`}>
                      <Users className="h-4 w-4 mr-1" />Issues
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default ProjectsPage;
