
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowRight,
  CheckCircle2,
  CircleDashed,
  Code,
  Copy,
  PenLine,
  Plus,
  Save,
  Trash2,
  Workflow,
  X,
  Mail,
  AlertCircle,
  User,
  MessageSquare,
  FileText,
  ChevronDown,
  ChevronRight,
  Check
} from "lucide-react";

interface WorkflowStep {
  id: string;
  type: "start" | "end" | "condition" | "action" | "notification" | "assignment" | "approval";
  label: string;
  description?: string;
  status?: string;
  config?: any;
  nextSteps?: string[];
  x: number;
  y: number;
}

interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  steps: number;
  author: {
    name: string;
    avatar: string;
  };
  lastModified: string;
  usage: number;
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: "draft" | "active" | "inactive";
  category: string;
  steps: WorkflowStep[];
  connections: {
    from: string;
    to: string;
    condition?: string;
  }[];
  triggers: {
    type: string;
    config: any;
  }[];
  lastModified: string;
  author: {
    name: string;
    avatar: string;
  };
}

const currentWorkflow: Workflow = {
  id: "workflow-1",
  name: "Critical Bug Resolution Process",
  description: "Workflow for handling critical bugs with expedited review and resolution",
  status: "active",
  category: "Support",
  steps: [
    {
      id: "step-1",
      type: "start",
      label: "Bug Report Submitted",
      x: 100,
      y: 100
    },
    {
      id: "step-2",
      type: "condition",
      label: "Is Critical?",
      description: "Check if bug is marked as critical severity",
      x: 250,
      y: 100
    },
    {
      id: "step-3",
      type: "notification",
      label: "Alert Development Team",
      description: "Send immediate notification to dev team leads",
      status: "active",
      config: {
        channel: "email",
        recipients: ["dev-team@example.com"],
        template: "critical-bug-alert"
      },
      x: 400,
      y: 50
    },
    {
      id: "step-4",
      type: "assignment",
      label: "Assign to Senior Developer",
      description: "Auto-assign ticket to available senior developer",
      config: {
        role: "senior-developer",
        assignmentRule: "round-robin"
      },
      x: 400,
      y: 150
    },
    {
      id: "step-5",
      type: "action",
      label: "Create Incident Report",
      description: "Generate initial incident report document",
      x: 550,
      y: 100
    },
    {
      id: "step-6",
      type: "approval",
      label: "Validate Fix",
      description: "QA team validates the fix",
      x: 700,
      y: 100
    },
    {
      id: "step-7",
      type: "end",
      label: "Bug Resolved",
      x: 850,
      y: 100
    }
  ],
  connections: [
    { from: "step-1", to: "step-2" },
    { from: "step-2", to: "step-3", condition: "Yes" },
    { from: "step-2", to: "step-4", condition: "No" },
    { from: "step-3", to: "step-5" },
    { from: "step-4", to: "step-5" },
    { from: "step-5", to: "step-6" },
    { from: "step-6", to: "step-7" }
  ],
  triggers: [
    {
      type: "ticket_created",
      config: {
        conditions: [
          { field: "category", operator: "equals", value: "bug" }
        ]
      }
    }
  ],
  lastModified: "2025-05-05T11:30:00Z",
  author: {
    name: "Michael Chen",
    avatar: "MC"
  }
};

// Helper function to get color for step type
const getStepTypeColor = (type: string) => {
  switch (type) {
    case "start":
      return "bg-green-100 text-green-700 border-green-200";
    case "end":
      return "bg-purple-100 text-purple-700 border-purple-200";
    case "condition":
      return "bg-amber-100 text-amber-700 border-amber-200";
    case "action":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "notification":
      return "bg-red-100 text-red-700 border-red-200";
    case "assignment":
      return "bg-indigo-100 text-indigo-700 border-indigo-200";
    case "approval":
      return "bg-orange-100 text-orange-700 border-orange-200";
    default:
      return "bg-gray-100 text-gray-700 border-gray-200";
  }
};

// Helper function to get icon for step type
const getStepTypeIcon = (type: string) => {
  switch (type) {
    case "start":
      return <CircleDashed className="h-4 w-4" />;
    case "end":
      return <CheckCircle2 className="h-4 w-4" />;
    case "condition":
      return <Code className="h-4 w-4" />;
    case "action":
      return <Workflow className="h-4 w-4" />;
    case "notification":
      return <Mail className="h-4 w-4" />;
    case "assignment":
      return <User className="h-4 w-4" />;
    case "approval":
      return <CheckCircle2 className="h-4 w-4" />;
    default:
      return <CircleDashed className="h-4 w-4" />;
  }
};

const WorkflowStudioPage = () => {
  const [activeTab, setActiveTab] = useState<string>("builder");
  const [selectedStep, setSelectedStep] = useState<WorkflowStep | null>(null);
  const [editingName, setEditingName] = useState<string>(currentWorkflow.name);
  const [editingDescription, setEditingDescription] = useState<string>(currentWorkflow.description);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const handleSaveWorkflow = () => {
    toast({
      title: "Workflow Saved",
      description: "Your workflow has been saved successfully"
    });
  };
  
  const handleActivateWorkflow = () => {
    toast({
      title: "Workflow Activated",
      description: "Your workflow is now active and processing tickets"
    });
  };

  const handleAddStep = (type: string) => {
    toast({
      title: "Step Added",
      description: `New ${type} step has been added to the workflow`
    });
  };

  const handleSelectStep = (step: WorkflowStep) => {
    setSelectedStep(step);
  };

  const handleDeselectStep = () => {
    setSelectedStep(null);
  };

  const handleDuplicateWorkflow = () => {
    toast({
      title: "Workflow Duplicated",
      description: "A copy of this workflow has been created"
    });
  };

  return (
    <Layout>
      <div className="animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">Workflow Studio</h1>
              <Badge variant={currentWorkflow.status === "active" ? "default" : "outline"}>
                {currentWorkflow.status.charAt(0).toUpperCase() + currentWorkflow.status.slice(1)}
              </Badge>
            </div>
            <p className="text-gray-500">Build and automate complex ticket workflows with no-code tools</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={handleDuplicateWorkflow}>
              <Copy className="h-4 w-4 mr-2" />
              Duplicate
            </Button>
            <Button variant="outline" onClick={handleSaveWorkflow}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
            {currentWorkflow.status !== "active" && (
              <Button onClick={handleActivateWorkflow}>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Activate
              </Button>
            )}
          </div>
        </div>

        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="workflow-name" className="block text-sm font-medium text-gray-700 mb-1">
                  Workflow Name
                </label>
                <Input
                  id="workflow-name"
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  className="mb-4"
                />
                <label htmlFor="workflow-description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <Input
                  id="workflow-description"
                  value={editingDescription}
                  onChange={(e) => setEditingDescription(e.target.value)}
                />
              </div>
              <div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <Select defaultValue={currentWorkflow.category}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Support">Support</SelectItem>
                        <SelectItem value="Customer Management">Customer Management</SelectItem>
                        <SelectItem value="Product Management">Product Management</SelectItem>
                        <SelectItem value="Development">Development</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Trigger</label>
                    <Select defaultValue="ticket_created">
                      <SelectTrigger>
                        <SelectValue placeholder="Select trigger" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ticket_created">Ticket Created</SelectItem>
                        <SelectItem value="ticket_updated">Ticket Updated</SelectItem>
                        <SelectItem value="form_submitted">Form Submitted</SelectItem>
                        <SelectItem value="status_changed">Status Changed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left sidebar - Steps toolbox */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Workflow Steps</CardTitle>
                <CardDescription>Drag and drop steps to build your workflow</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div 
                    className="border rounded-lg p-3 cursor-pointer hover:border-primary transition-all"
                    onClick={() => handleAddStep("condition")}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${getStepTypeColor("condition")}`}>
                        {getStepTypeIcon("condition")}
                      </div>
                      <div>
                        <h4 className="font-medium">Condition</h4>
                        <p className="text-xs text-gray-500">Add a decision branch</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="border rounded-lg p-3 cursor-pointer hover:border-primary transition-all"
                    onClick={() => handleAddStep("action")}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${getStepTypeColor("action")}`}>
                        {getStepTypeIcon("action")}
                      </div>
                      <div>
                        <h4 className="font-medium">Action</h4>
                        <p className="text-xs text-gray-500">Perform an operation</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="border rounded-lg p-3 cursor-pointer hover:border-primary transition-all"
                    onClick={() => handleAddStep("notification")}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${getStepTypeColor("notification")}`}>
                        {getStepTypeIcon("notification")}
                      </div>
                      <div>
                        <h4 className="font-medium">Notification</h4>
                        <p className="text-xs text-gray-500">Send alerts or messages</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="border rounded-lg p-3 cursor-pointer hover:border-primary transition-all"
                    onClick={() => handleAddStep("assignment")}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${getStepTypeColor("assignment")}`}>
                        {getStepTypeIcon("assignment")}
                      </div>
                      <div>
                        <h4 className="font-medium">Assignment</h4>
                        <p className="text-xs text-gray-500">Assign to user or team</p>
                      </div>
                    </div>
                  </div>
                  
                  <div 
                    className="border rounded-lg p-3 cursor-pointer hover:border-primary transition-all"
                    onClick={() => handleAddStep("approval")}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md ${getStepTypeColor("approval")}`}>
                        {getStepTypeIcon("approval")}
                      </div>
                      <div>
                        <h4 className="font-medium">Approval</h4>
                        <p className="text-xs text-gray-500">Request approval step</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main workflow builder canvas */}
          <div className="lg:col-span-2">
            <Card className="h-full min-h-[500px]">
              <CardHeader className="border-b bg-gray-50">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-base">Workflow Builder</CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <PenLine className="h-4 w-4 mr-2" />
                      Annotate
                    </Button>
                    <Button variant="outline" size="sm">
                      <Copy className="h-4 w-4 mr-2" />
                      Test
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 h-[500px] overflow-auto bg-gray-50 relative">
                {/* Simple canvas representation */}
                <div className="p-8 text-center">
                  <h3 className="font-medium">Workflow Builder Canvas</h3>
                  <p className="text-sm text-gray-500 mt-2">Drag and drop steps from the left panel to create your workflow</p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Right sidebar - Step properties */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>
                  {selectedStep ? "Step Properties" : "Workflow Details"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center text-gray-500 p-4">
                  {selectedStep ? (
                    <p>Select a step to see its properties</p>
                  ) : (
                    <p>Select or add a step to configure</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default WorkflowStudioPage;
