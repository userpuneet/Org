import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Plus, Loader2, AlertTriangle, Clock, Trash2, CheckCircle2 } from "lucide-react";
import { useSLAPolicies } from "@/hooks/useSLAPolicies";

const priorityColors: Record<string, string> = {
  critical: "bg-red-50 text-red-600 border-red-200",
  high: "bg-orange-50 text-orange-600 border-orange-200",
  medium: "bg-yellow-50 text-yellow-600 border-yellow-200",
  low: "bg-green-50 text-green-600 border-green-200",
};

const SLAManagementPage = () => {
  const { policies, loading, create, update, remove, checkBreaches } = useSLAPolicies();
  const [breaches, setBreaches] = useState<Awaited<ReturnType<typeof checkBreaches>>>([]);
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: "", description: "",
    priority: "medium" as "low"|"medium"|"high"|"critical",
    first_response_hours: 8, resolution_hours: 72, is_active: true,
  });

  useEffect(() => {
    if (policies.length > 0) checkBreaches().then(setBreaches);
  }, [policies, checkBreaches]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try { await create(form); setOpen(false); setForm({ name: "", description: "", priority: "medium", first_response_hours: 8, resolution_hours: 72, is_active: true }); }
    finally { setSubmitting(false); }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">SLA Management</h1>
            <p className="text-gray-600 mt-1">Define response and resolution time targets by priority</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" />New Policy</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Create SLA Policy</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 mt-2">
                <Input placeholder="Policy name" value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} required />
                <Input placeholder="Description (optional)" value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))} />
                <Select value={form.priority} onValueChange={v => setForm(f => ({...f, priority: v as typeof form.priority}))}>
                  <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">First Response (hours)</label>
                    <Input type="number" min={1} value={form.first_response_hours}
                      onChange={e => setForm(f => ({...f, first_response_hours: +e.target.value}))} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Resolution (hours)</label>
                    <Input type="number" min={1} value={form.resolution_hours}
                      onChange={e => setForm(f => ({...f, resolution_hours: +e.target.value}))} />
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={submitting}>
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create Policy"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* SLA Breach alerts */}
        {breaches.length > 0 && (
          <Card className="border-red-200 bg-red-50">
            <CardHeader className="pb-2">
              <CardTitle className="text-red-700 flex items-center gap-2 text-base">
                <AlertTriangle className="h-5 w-5" />{breaches.length} Active SLA Breach{breaches.length > 1 ? "es" : ""}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {breaches.slice(0, 5).map(b => (
                <div key={b.threadId} className="flex items-center justify-between text-sm bg-white rounded p-2 border border-red-100">
                  <span className="font-medium truncate">{b.title}</span>
                  <span className="text-red-600 ml-2 whitespace-nowrap">
                    {b.type === "resolution" ? "Resolution" : "Response"} overdue by {b.hoursOverdue}h
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {loading && <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-gray-400" /></div>}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {policies.map(p => (
            <Card key={p.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base flex items-center gap-2">
                      {p.name}
                      {p.is_active
                        ? <CheckCircle2 className="h-4 w-4 text-green-500" />
                        : <span className="text-xs text-gray-400 font-normal">(inactive)</span>}
                    </CardTitle>
                    {p.description && <CardDescription className="mt-1">{p.description}</CardDescription>}
                  </div>
                  <Badge variant="outline" className={priorityColors[p.priority]}>{p.priority}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-gray-50 rounded p-3 text-center">
                    <div className="text-xs text-gray-500 mb-1 flex items-center justify-center gap-1"><Clock className="h-3 w-3" />First Response</div>
                    <div className="text-xl font-bold">{p.first_response_hours}h</div>
                  </div>
                  <div className="bg-gray-50 rounded p-3 text-center">
                    <div className="text-xs text-gray-500 mb-1 flex items-center justify-center gap-1"><Clock className="h-3 w-3" />Resolution</div>
                    <div className="text-xl font-bold">{p.resolution_hours}h</div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm">
                    <Switch checked={p.is_active} onCheckedChange={v => update(p.id, { is_active: v })} />
                    <span className="text-gray-600">{p.is_active ? "Active" : "Inactive"}</span>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-red-500"
                    onClick={() => remove(p.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {!loading && policies.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <Clock className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p className="font-medium">No SLA policies yet</p>
            <p className="text-sm">Create policies to define response time targets</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default SLAManagementPage;
