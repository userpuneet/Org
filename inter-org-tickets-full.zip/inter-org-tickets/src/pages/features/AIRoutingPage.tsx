
import { useState } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";

interface ClassifiedTicket {
  id: string;
  title: string;
  content: string;
  category: string;
  confidence: number;
  suggestedTeam: string;
  suggestedAgent: {
    name: string;
    avatar: string;
    specialty: string;
    successRate: number;
  };
  priority: "low" | "medium" | "high" | "critical";
  status: "new" | "processed" | "assigned";
}

const dummyTickets: ClassifiedTicket[] = [
  {
    id: "TK-1001",
    title: "Application crashing on login",
    content: "Our team is experiencing consistent crashes when trying to log in to the application using SSO. This started occurring after the latest update.",
    category: "Bug Report",
    confidence: 92,
    suggestedTeam: "Technical Support",
    suggestedAgent: {
      name: "Alex Wong",
      avatar: "AW",
      specialty: "Authentication Issues",
      successRate: 95
    },
    priority: "high",
    status: "new"
  },
  {
    id: "TK-1002",
    title: "Need access to marketing module",
    content: "Our marketing team requires access to the analytics dashboard in order to track our new campaign performance.",
    category: "Access Request",
    confidence: 88,
    suggestedTeam: "Account Management",
    suggestedAgent: {
      name: "Taylor Smith",
      avatar: "TS",
      specialty: "Permission Management",
      successRate: 92
    },
    priority: "medium",
    status: "new"
  },
  {
    id: "TK-1003",
    title: "Feature request: dark mode support",
    content: "We'd like to request dark mode support for the application to improve user experience during night shifts.",
    category: "Feature Request",
    confidence: 94,
    suggestedTeam: "Product Management",
    suggestedAgent: {
      name: "Jordan Lee",
      avatar: "JL",
      specialty: "UI/UX Enhancements",
      successRate: 89
    },
    priority: "low",
    status: "new"
  },
  {
    id: "TK-1004",
    title: "Database connection timeout",
    content: "Our production environment is experiencing intermittent database connection timeouts causing service disruption.",
    category: "Critical Issue",
    confidence: 97,
    suggestedTeam: "Database Operations",
    suggestedAgent: {
      name: "Morgan Chen",
      avatar: "MC",
      specialty: "Database Performance",
      successRate: 98
    },
    priority: "critical",
    status: "new"
  },
  {
    id: "TK-1005",
    title: "Billing discrepancy for March invoice",
    content: "We noticed that our March invoice includes charges for services we didn't use. Please review and adjust accordingly.",
    category: "Billing Inquiry",
    confidence: 85,
    suggestedTeam: "Finance Support",
    suggestedAgent: {
      name: "Riley Johnson",
      avatar: "RJ",
      specialty: "Billing Resolution",
      successRate: 94
    },
    priority: "medium",
    status: "new"
  }
];

const AIRoutingPage = () => {
  const [tickets, setTickets] = useState(dummyTickets);
  const { toast } = useToast();
  
  const handleAssignTicket = (ticketId: string) => {
    setTickets(prevTickets => 
      prevTickets.map(ticket => 
        ticket.id === ticketId 
          ? { ...ticket, status: "assigned" as const }
          : ticket
      )
    );
    
    toast({
      title: "Ticket Assigned",
      description: "Ticket has been automatically assigned based on AI recommendation"
    });
  };
  
  const handleProcessAllTickets = () => {
    setTickets(prevTickets => 
      prevTickets.map(ticket => 
        ticket.status === "new"
          ? { ...ticket, status: "processed" as const }
          : ticket
      )
    );
    
    toast({
      title: "Tickets Processed",
      description: "All tickets have been processed by AI"
    });
  };

  return (
    <Layout>
      <div className="animate-fade-in">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold">AI-Powered Ticket Routing</h1>
            <p className="text-gray-500">Automatically classify and route tickets to the appropriate teams and agents</p>
          </div>
          <Button onClick={handleProcessAllTickets}>Process All New Tickets</Button>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>AI Classification Model Performance</CardTitle>
            <CardDescription>Real-time monitoring of our AI classification model</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Classification Accuracy</p>
                <h3 className="text-3xl font-bold">94.7%</h3>
                <p className="text-xs text-green-600">↑ 2.3% from last month</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Assignment Precision</p>
                <h3 className="text-3xl font-bold">91.2%</h3>
                <p className="text-xs text-green-600">↑ 1.5% from last month</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Processing Time</p>
                <h3 className="text-3xl font-bold">3.2s</h3>
                <p className="text-xs text-green-600">↓ 0.8s from last month</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Manual Overrides</p>
                <h3 className="text-3xl font-bold">6.8%</h3>
                <p className="text-xs text-green-600">↓ 3.2% from last month</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="new">
          <TabsList className="mb-4">
            <TabsTrigger value="new">
              New Tickets <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-600">{tickets.filter(t => t.status === "new").length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="processed">
              Processed <Badge variant="outline" className="ml-2 bg-purple-50 text-purple-600">{tickets.filter(t => t.status === "processed").length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="assigned">
              Assigned <Badge variant="outline" className="ml-2 bg-green-50 text-green-600">{tickets.filter(t => t.status === "assigned").length}</Badge>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="new">
            <div className="space-y-4">
              {tickets.filter(ticket => ticket.status === "new").map(ticket => (
                <Card key={ticket.id} className="overflow-hidden">
                  <div className="border-l-4 border-blue-500">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-500">{ticket.id}</span>
                            <CardTitle>{ticket.title}</CardTitle>
                          </div>
                          <CardDescription className="mt-1 line-clamp-2">{ticket.content}</CardDescription>
                        </div>
                        <Badge variant={ticket.priority === "critical" ? "destructive" : ticket.priority === "high" ? "default" : "outline"}>
                          {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)} Priority
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-medium text-blue-700 mb-3">AI Classification Results</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-sm text-gray-500">Category</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="bg-blue-50">
                                {ticket.category}
                              </Badge>
                              <span className="text-xs text-blue-700">({ticket.confidence}% confidence)</span>
                            </div>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Suggested Team</p>
                            <p className="font-medium">{ticket.suggestedTeam}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Suggested Agent</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Avatar className="h-6 w-6">
                                <AvatarFallback>{ticket.suggestedAgent.avatar}</AvatarFallback>
                              </Avatar>
                              <span className="font-medium">{ticket.suggestedAgent.name}</span>
                              <span className="text-xs text-green-600">({ticket.suggestedAgent.successRate}% success rate)</span>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">Specialty: {ticket.suggestedAgent.specialty}</p>
                          </div>
                        </div>
                        <div className="mt-4 flex justify-end">
                          <Button size="sm" onClick={() => handleAssignTicket(ticket.id)}>
                            Assign as Recommended
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
              
              {tickets.filter(ticket => ticket.status === "new").length === 0 && (
                <div className="text-center py-12 border rounded-lg">
                  <p className="text-gray-500">No new tickets to process</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="processed">
            <div className="space-y-4">
              {tickets.filter(ticket => ticket.status === "processed").map(ticket => (
                <Card key={ticket.id} className="overflow-hidden">
                  <div className="border-l-4 border-purple-500">
                    <CardHeader>
                      <div className="flex justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-500">{ticket.id}</span>
                            <CardTitle>{ticket.title}</CardTitle>
                          </div>
                        </div>
                        <Badge variant="outline" className="bg-purple-50 text-purple-600">Processed</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-purple-50 p-4 rounded-lg">
                        <h4 className="font-medium text-purple-700 mb-3">Ready for Assignment</h4>
                        <p>This ticket has been processed and classified by the AI system.</p>
                        <div className="mt-4 flex justify-end">
                          <Button size="sm" onClick={() => handleAssignTicket(ticket.id)}>
                            Assign Now
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
              
              {tickets.filter(ticket => ticket.status === "processed").length === 0 && (
                <div className="text-center py-12 border rounded-lg">
                  <p className="text-gray-500">No processed tickets</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="assigned">
            <div className="space-y-4">
              {tickets.filter(ticket => ticket.status === "assigned").map(ticket => (
                <Card key={ticket.id} className="overflow-hidden">
                  <div className="border-l-4 border-green-500">
                    <CardHeader>
                      <div className="flex justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-500">{ticket.id}</span>
                            <CardTitle>{ticket.title}</CardTitle>
                          </div>
                        </div>
                        <Badge variant="outline" className="bg-green-50 text-green-600">Assigned</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h4 className="font-medium text-green-700">Successfully Assigned</h4>
                        <div className="flex items-center gap-2 mt-2">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback>{ticket.suggestedAgent.avatar}</AvatarFallback>
                          </Avatar>
                          <span>Assigned to <span className="font-medium">{ticket.suggestedAgent.name}</span> from {ticket.suggestedTeam}</span>
                        </div>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
              
              {tickets.filter(ticket => ticket.status === "assigned").length === 0 && (
                <div className="text-center py-12 border rounded-lg">
                  <p className="text-gray-500">No assigned tickets</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default AIRoutingPage;
