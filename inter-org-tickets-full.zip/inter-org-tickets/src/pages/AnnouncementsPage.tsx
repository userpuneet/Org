import { useState } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Bell, Plus, Loader2 } from "lucide-react";
import { useAnnouncements, type AnnouncementCategory } from "@/hooks/useAnnouncements";
import { useAuth } from "@/contexts/AuthContext";

const categoryColors: Record<string, string> = {
  maintenance: "bg-amber-50 text-amber-600 border-amber-200",
  feature:     "bg-green-50 text-green-600 border-green-200",
  security:    "bg-red-50 text-red-600 border-red-200",
  system:      "bg-blue-50 text-blue-600 border-blue-200",
  other:       "bg-gray-50 text-gray-600 border-gray-200",
};
const categoryLabels: Record<string, string> = {
  maintenance: "Maintenance", feature: "New Feature", security: "Security",
  system: "System", other: "Other",
};

const formatDate = (s: string) => new Date(s).toLocaleDateString("en-US", {
  month: "long", day: "numeric", year: "numeric"
});

const AnnouncementsPage = () => {
  const { profile } = useAuth();
  const [filter, setFilter] = useState<AnnouncementCategory | undefined>();
  const { announcements, loading, error, create } = useAnnouncements(filter);

  const [open, setOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newCategory, setNewCategory] = useState<AnnouncementCategory>("feature");
  const [newImportant, setNewImportant] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await create({ title: newTitle, content: newContent, category: newCategory, is_important: newImportant });
      setOpen(false);
      setNewTitle(""); setNewContent(""); setNewCategory("feature"); setNewImportant(false);
    } finally { setSubmitting(false); }
  };

  const filters: Array<{ label: string; value: AnnouncementCategory | undefined }> = [
    { label: "All", value: undefined },
    { label: "Maintenance", value: "maintenance" },
    { label: "Features", value: "feature" },
    { label: "Security", value: "security" },
    { label: "System", value: "system" },
  ];

  return (
    <Layout>
      <div className="animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <h1 className="text-2xl font-bold flex items-center">
            <Bell className="mr-2 h-6 w-6" /> System Announcements
          </h1>
          <div className="flex items-center gap-3 flex-wrap">
            {filters.map(f => (
              <Badge key={String(f.value)}
                variant={filter === f.value ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setFilter(f.value)}>
                {f.label}
              </Badge>
            ))}
            {profile?.role === "admin" && (
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                  <Button size="sm"><Plus className="h-4 w-4 mr-1" />Post</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>New Announcement</DialogTitle></DialogHeader>
                  <form onSubmit={handleCreate} className="space-y-4 mt-2">
                    <Input placeholder="Title" value={newTitle} onChange={e => setNewTitle(e.target.value)} required />
                    <Textarea placeholder="Content…" value={newContent} onChange={e => setNewContent(e.target.value)} required className="min-h-[120px]" />
                    <Select value={newCategory} onValueChange={v => setNewCategory(v as AnnouncementCategory)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="feature">New Feature</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="security">Security</SelectItem>
                        <SelectItem value="system">System</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <input type="checkbox" checked={newImportant} onChange={e => setNewImportant(e.target.checked)} className="rounded" />
                      Mark as Important
                    </label>
                    <Button type="submit" className="w-full" disabled={submitting}>
                      {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Post Announcement"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        {loading && <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-gray-400" /></div>}
        {error && <p className="text-red-500 text-sm">{error}</p>}

        <div className="space-y-4">
          {!loading && announcements.length === 0 && (
            <div className="text-center p-8 text-gray-500">No announcements found.</div>
          )}
          {announcements.map(a => (
            <Card key={a.id} className={a.is_important ? "border-red-200" : ""}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {a.title}
                      {a.is_important && <Badge className="bg-red-500">Important</Badge>}
                    </CardTitle>
                    <CardDescription>{formatDate(a.published_at)}</CardDescription>
                  </div>
                  <Badge variant="outline" className={categoryColors[a.category]}>
                    {categoryLabels[a.category]}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent><p className="whitespace-pre-line">{a.content}</p></CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default AnnouncementsPage;
