import { useState, useMemo } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ChevronLeft, ChevronRight, Plus, Loader2, Trash2, Clock } from "lucide-react";
import { useCalendarEvents, type EventType } from "@/hooks/useCalendarEvents";

const typeColors: Record<string, string> = {
  meeting: "bg-blue-100 text-blue-700",
  maintenance: "bg-amber-100 text-amber-700",
  deadline: "bg-red-100 text-red-700",
  reminder: "bg-purple-100 text-purple-700",
  other: "bg-gray-100 text-gray-700",
};

const fmt = (d: string) => new Date(d).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
const fmtDate = (d: string) => new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric" });

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

const CalendarPage = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const { events, loading, create, remove } = useCalendarEvents(currentMonth);

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "", description: "", event_type: "meeting" as EventType,
    priority: "medium" as "low" | "medium" | "high",
    date: "", startTime: "09:00", endTime: "10:00"
  });
  const [submitting, setSubmitting] = useState(false);

  const prevMonth = () => setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() - 1, 1));
  const nextMonth = () => setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() + 1, 1));

  // Build grid
  const firstDay = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();

  const eventsByDay = useMemo(() => {
    const map: Record<number, typeof events> = {};
    events.forEach(ev => {
      const d = new Date(ev.starts_at).getDate();
      if (!map[d]) map[d] = [];
      map[d].push(ev);
    });
    return map;
  }, [events]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const starts_at = new Date(`${form.date}T${form.startTime}`).toISOString();
      const ends_at   = new Date(`${form.date}T${form.endTime}`).toISOString();
      await create({ title: form.title, description: form.description, event_type: form.event_type, priority: form.priority, starts_at, ends_at });
      setOpen(false);
      setForm({ title: "", description: "", event_type: "meeting", priority: "medium", date: "", startTime: "09:00", endTime: "10:00" });
    } finally { setSubmitting(false); }
  };

  const today = new Date();

  return (
    <Layout>
      <div className="animate-fade-in space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Calendar</h1>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" />Add Event</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New Event</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-3 mt-2">
                <Input placeholder="Event title" value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))} required />
                <Input placeholder="Description (optional)" value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))} />
                <Select value={form.event_type} onValueChange={v => setForm(f => ({...f, event_type: v as EventType}))}>
                  <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="meeting">Meeting</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="deadline">Deadline</SelectItem>
                    <SelectItem value="reminder">Reminder</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={form.priority} onValueChange={v => setForm(f => ({...f, priority: v as "low"|"medium"|"high"}))}>
                  <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
                <Input type="date" value={form.date} onChange={e => setForm(f => ({...f, date: e.target.value}))} required />
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="text-xs text-gray-500 mb-1 block">Start</label><Input type="time" value={form.startTime} onChange={e => setForm(f => ({...f, startTime: e.target.value}))} /></div>
                  <div><label className="text-xs text-gray-500 mb-1 block">End</label><Input type="time" value={form.endTime} onChange={e => setForm(f => ({...f, endTime: e.target.value}))} /></div>
                </div>
                <Button type="submit" className="w-full" disabled={submitting}>
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create Event"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle>{MONTHS[currentMonth.getMonth()]} {currentMonth.getFullYear()}</CardTitle>
                <div className="flex gap-1">
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={prevMonth}><ChevronLeft className="h-4 w-4" /></Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={nextMonth}><ChevronRight className="h-4 w-4" /></Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-gray-400" /></div> : (
                <>
                  <div className="grid grid-cols-7 gap-px mb-2">
                    {DAYS.map(d => <div key={d} className="text-xs font-medium text-gray-500 text-center py-1">{d}</div>)}
                  </div>
                  <div className="grid grid-cols-7 gap-px">
                    {Array.from({ length: firstDay }).map((_, i) => <div key={`empty-${i}`} />)}
                    {Array.from({ length: daysInMonth }).map((_, i) => {
                      const day = i + 1;
                      const isToday = today.getDate() === day && today.getMonth() === currentMonth.getMonth() && today.getFullYear() === currentMonth.getFullYear();
                      const dayEvents = eventsByDay[day] ?? [];
                      return (
                        <div key={day} className={`min-h-[64px] p-1 rounded border text-xs ${isToday ? "bg-primary/5 border-primary" : "border-gray-100"}`}>
                          <div className={`font-medium mb-1 w-6 h-6 flex items-center justify-center rounded-full text-xs ${isToday ? "bg-primary text-white" : "text-gray-700"}`}>{day}</div>
                          {dayEvents.slice(0, 2).map(ev => (
                            <div key={ev.id} className={`rounded px-1 py-0.5 mb-0.5 truncate ${typeColors[ev.event_type]}`}>{ev.title}</div>
                          ))}
                          {dayEvents.length > 2 && <div className="text-gray-400 text-[10px]">+{dayEvents.length - 2} more</div>}
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Upcoming Events</CardTitle></CardHeader>
            <CardContent className="space-y-3 max-h-[480px] overflow-y-auto">
              {events.length === 0 && !loading && <p className="text-sm text-gray-500 text-center py-4">No events this month</p>}
              {events.map(ev => (
                <div key={ev.id} className="border rounded-lg p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{ev.title}</p>
                      <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                        <Clock className="h-3 w-3" />
                        {fmtDate(ev.starts_at)} · {fmt(ev.starts_at)} – {fmt(ev.ends_at)}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Badge variant="outline" className={`text-xs ${typeColors[ev.event_type]}`}>{ev.event_type}</Badge>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-400 hover:text-red-500" onClick={() => remove(ev.id)}>
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  {ev.description && <p className="text-xs text-gray-600 mt-1 line-clamp-2">{ev.description}</p>}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default CalendarPage;
