import { useState } from "react";
import Layout from "@/components/Layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, UserPlus, Search, Shield, Loader2, Mail } from "lucide-react";
import { useProfiles } from "@/hooks/useProfiles";
import type { Profile } from "@/contexts/AuthContext";

const roleBadge = (role: string) => {
  const styles: Record<string, string> = {
    admin: "bg-purple-50 text-purple-600 border-purple-200",
    user: "bg-blue-50 text-blue-600 border-blue-200",
    viewer: "bg-gray-50 text-gray-600 border-gray-200",
  };
  return <Badge variant="outline" className={styles[role] ?? ""}>{role}</Badge>;
};

const statusBadge = (status: string) => {
  const styles: Record<string, string> = {
    active: "bg-green-50 text-green-600 border-green-200",
    inactive: "bg-gray-50 text-gray-600 border-gray-200",
    pending: "bg-amber-50 text-amber-600 border-amber-200",
  };
  return <Badge variant="outline" className={styles[status] ?? ""}>{status}</Badge>;
};

const UserManagementPage = () => {
  const [search, setSearch] = useState("");
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("user");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviting, setInviting] = useState(false);

  const { profiles, loading, error, updateRole, updateStatus, inviteUser } = useProfiles(search);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setInviting(true);
    try { await inviteUser(inviteEmail, inviteRole); setInviteOpen(false); setInviteEmail(""); }
    finally { setInviting(false); }
  };

  const initials = (p: Profile) => {
    const name = p.full_name ?? p.email;
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
            <p className="text-gray-600 mt-1">Manage users, roles, and permissions</p>
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input placeholder="Search users..." className="pl-9 w-64" value={search}
                onChange={e => setSearch(e.target.value)} />
            </div>
            <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
              <DialogTrigger asChild>
                <Button><UserPlus className="h-4 w-4 mr-2" />Invite User</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Invite User</DialogTitle></DialogHeader>
                <form onSubmit={handleInvite} className="space-y-4 mt-2">
                  <div>
                    <label className="text-sm font-medium">Email Address</label>
                    <Input type="email" className="mt-1" placeholder="colleague@company.com"
                      value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} required />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Role</label>
                    <Select value={inviteRole} onValueChange={setInviteRole}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="viewer">Viewer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="w-full" disabled={inviting}>
                    {inviting ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Mail className="h-4 w-4 mr-2" />Send Invite</>}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="users">
          <TabsList>
            <TabsTrigger value="users"><Users className="h-4 w-4 mr-2" />Users</TabsTrigger>
            <TabsTrigger value="permissions"><Shield className="h-4 w-4 mr-2" />Roles & Permissions</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-4">
            {loading && <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-gray-400" /></div>}
            {error && <p className="text-red-500">{error}</p>}
            <div className="space-y-2">
              {profiles.map(p => (
                <Card key={p.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarFallback className="bg-primary/10 text-primary font-medium">{initials(p)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{p.full_name ?? p.email}</p>
                        <p className="text-sm text-gray-500 truncate">{p.email}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        {statusBadge(p.status)}
                        <Select value={p.role} onValueChange={v => updateRole(p.id, v as Profile["role"])}>
                          <SelectTrigger className="w-24 h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Admin</SelectItem>
                            <SelectItem value="user">User</SelectItem>
                            <SelectItem value="viewer">Viewer</SelectItem>
                          </SelectContent>
                        </Select>
                        <Select value={p.status} onValueChange={v => updateStatus(p.id, v as Profile["status"])}>
                          <SelectTrigger className="w-28 h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="inactive">Inactive</SelectItem>
                            <SelectItem value="pending">Pending</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {!loading && profiles.length === 0 && (
                <div className="text-center py-12 text-gray-500">No users found</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="permissions" className="mt-4">
            <Card>
              <CardHeader><CardTitle>Role Permissions</CardTitle></CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 pr-4 font-medium">Permission</th>
                        <th className="text-center px-4 font-medium">Admin</th>
                        <th className="text-center px-4 font-medium">User</th>
                        <th className="text-center px-4 font-medium">Viewer</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        ["Create threads", true, true, false],
                        ["View all threads", true, true, true],
                        ["Edit any thread", true, false, false],
                        ["Delete threads", true, false, false],
                        ["Invite users", true, false, false],
                        ["Manage roles", true, false, false],
                        ["Create projects", true, true, false],
                        ["Post announcements", true, false, false],
                        ["View reports", true, true, true],
                        ["Manage SLA policies", true, false, false],
                      ].map(([label, admin, user, viewer]) => (
                        <tr key={label as string} className="border-b last:border-0">
                          <td className="py-2 pr-4 text-gray-700">{label as string}</td>
                          {[admin, user, viewer].map((v, i) => (
                            <td key={i} className="text-center px-4 py-2">
                              <span className={`text-lg ${v ? "text-green-500" : "text-gray-300"}`}>{v ? "✓" : "✗"}</span>
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default UserManagementPage;
