import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Flag, MoreVertical, Clock, Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Layout from '@/components/Layout';
import { useParams } from 'react-router-dom';
import CreateIssueDialog from '@/components/project/CreateIssueDialog';
import { useProjectBoard } from '@/hooks/useProjectBoard';

const priorityColors: Record<string, string> = {
  Critical: 'text-red-500',
  High: 'text-orange-500',
  Medium: 'text-yellow-500',
  Low: 'text-green-500',
};

const IssuesPage = () => {
  const { projectKey } = useParams();
  const { project, issues, columns, statusesMap, loading, error, createIssue } = useProjectBoard(projectKey);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');

  const filtered = issues.filter(issue => {
    const matchSearch = !searchTerm ||
      issue.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (issue.external_key?.toLowerCase() ?? '').includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || issue.status_id === statusFilter;
    const matchPriority = priorityFilter === 'all' || issue.priority.toLowerCase() === priorityFilter;
    return matchSearch && matchStatus && matchPriority;
  });

  const handleCreate = async (data: { title: string; description?: string; priority?: string; assignee?: string }) => {
    await createIssue({
      title: data.title,
      description: data.description,
      priority: data.priority as any,
      assignee: data.assignee,
    });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{project?.name ?? projectKey} — Issues</h1>
            <p className="text-gray-600">{issues.length} total issues</p>
          </div>
          <CreateIssueDialog
            projectKey={projectKey ?? ''}
            onIssueCreate={handleCreate}
          />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input placeholder="Search issues..." value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)} className="pl-10" />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {columns.map(col => (
                <SelectItem key={col.statusId} value={col.statusId}>{col.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Priority" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {loading && <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-gray-400" /></div>}
        {error && <p className="text-red-500">{error}</p>}

        {!loading && (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-24">Key</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead className="w-28">Status</TableHead>
                    <TableHead className="w-24">Priority</TableHead>
                    <TableHead className="w-28">Assignee</TableHead>
                    <TableHead className="w-28">Updated</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                        {issues.length === 0 ? "No issues yet — create the first one!" : "No issues match your filters"}
                      </TableCell>
                    </TableRow>
                  )}
                  {filtered.map(issue => (
                    <TableRow key={issue.id} className="hover:bg-gray-50">
                      <TableCell className="font-mono text-xs text-gray-500">
                        {issue.external_key ?? issue.id.slice(0, 8)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{issue.title}</span>
                          {issue.labels && issue.labels.length > 0 && issue.labels.map(l => (
                            <Badge key={l} variant="outline" className="text-xs">{l}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {statusesMap[issue.status_id ?? '']?.name ?? 'Backlog'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Flag className={`h-3 w-3 ${priorityColors[issue.priority]}`} />
                          <span className="text-sm">{issue.priority}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {issue.assignee ? (
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-[10px]">
                                {issue.assignee.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span className="text-sm truncate max-w-[80px]">{issue.assignee}</span>
                          </div>
                        ) : <span className="text-gray-400 text-sm">—</span>}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Clock className="h-3 w-3" />
                          {new Date(issue.updated_at).toLocaleDateString()}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default IssuesPage;
