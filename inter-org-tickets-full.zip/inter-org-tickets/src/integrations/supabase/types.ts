// Auto-generated types for Supabase tables.
// These allow typed `.from("table")` calls without the full generated SDK.

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export interface Database {
  public: {
    Tables: {
      organizations: {
        Row: { id: string; name: string; slug: string; logo_url: string | null; created_at: string; updated_at: string };
        Insert: { id?: string; name: string; slug: string; logo_url?: string | null };
        Update: { name?: string; slug?: string; logo_url?: string | null };
      };
      profiles: {
        Row: { id: string; email: string; full_name: string | null; avatar_url: string | null; org_id: string | null; role: string; status: string; created_at: string; updated_at: string };
        Insert: { id: string; email: string; full_name?: string | null; avatar_url?: string | null; org_id?: string | null; role?: string; status?: string };
        Update: { full_name?: string | null; avatar_url?: string | null; org_id?: string | null; role?: string; status?: string };
      };
      invites: {
        Row: { id: string; email: string; org_id: string | null; role: string; invited_by: string | null; token: string; accepted_at: string | null; expires_at: string; created_at: string };
        Insert: { email: string; org_id?: string | null; role?: string; invited_by?: string | null };
        Update: { accepted_at?: string | null };
      };
      threads: {
        Row: { id: string; external_id: string | null; title: string; description: string | null; status: string; priority: string; relationship_type: string; raiser_org_id: string | null; recipient_org_id: string | null; raiser_id: string | null; assignee_id: string | null; eta_value: string | null; eta_unit: string | null; eta_set_at: string | null; eta_set_by: string | null; created_at: string; updated_at: string };
        Insert: { title: string; description?: string | null; status?: string; priority?: string; relationship_type?: string; raiser_org_id?: string | null; recipient_org_id?: string | null; raiser_id?: string | null; assignee_id?: string | null };
        Update: { title?: string; description?: string | null; status?: string; priority?: string; assignee_id?: string | null; eta_value?: string | null; eta_unit?: string | null };
      };
      comments: {
        Row: { id: string; thread_id: string | null; issue_id: string | null; author_id: string | null; author_name: string | null; author_org: string | null; content: string; is_internal: boolean; reply_to_id: string | null; category: string | null; is_edited: boolean; edited_at: string | null; created_at: string };
        Insert: { thread_id?: string | null; issue_id?: string | null; author_id?: string | null; author_name?: string | null; author_org?: string | null; content: string; is_internal?: boolean; reply_to_id?: string | null; category?: string | null };
        Update: { content?: string; is_edited?: boolean; edited_at?: string | null };
      };
      announcements: {
        Row: { id: string; title: string; content: string; category: string; is_important: boolean; author_id: string | null; org_id: string | null; published_at: string; expires_at: string | null; created_at: string; updated_at: string };
        Insert: { title: string; content: string; category?: string; is_important?: boolean; author_id?: string | null };
        Update: { title?: string; content?: string; category?: string; is_important?: boolean };
      };
      calendar_events: {
        Row: { id: string; title: string; description: string | null; event_type: string; priority: string; starts_at: string; ends_at: string; all_day: boolean; org_id: string | null; created_by: string | null; thread_id: string | null; created_at: string; updated_at: string };
        Insert: { title: string; description?: string | null; event_type?: string; priority?: string; starts_at: string; ends_at: string; all_day?: boolean };
        Update: { title?: string; description?: string | null; event_type?: string; starts_at?: string; ends_at?: string };
      };
      notifications: {
        Row: { id: string; user_id: string; title: string; body: string | null; type: string; entity_type: string | null; entity_id: string | null; is_read: boolean; created_at: string };
        Insert: { user_id: string; title: string; body?: string | null; type?: string; entity_type?: string | null; entity_id?: string | null };
        Update: { is_read?: boolean };
      };
      sla_policies: {
        Row: { id: string; name: string; description: string | null; org_id: string | null; priority: string; first_response_hours: number; resolution_hours: number; is_active: boolean; created_at: string; updated_at: string };
        Insert: { name: string; description?: string | null; priority: string; first_response_hours?: number; resolution_hours?: number; is_active?: boolean };
        Update: { name?: string; description?: string | null; priority?: string; first_response_hours?: number; resolution_hours?: number; is_active?: boolean };
      };
      projects: {
        Row: { id: string; key: string; name: string; description: string | null; created_at: string; updated_at: string };
        Insert: { key: string; name: string; description?: string | null };
        Update: { name?: string; description?: string | null };
      };
      issues: {
        Row: { id: string; project_id: string; external_key: string | null; title: string; description: string | null; type_id: string | null; priority: string; severity: string; status_id: string | null; assignee: string | null; reporter: string | null; story_points: number | null; labels: string[] | null; sprint_id: string | null; epic_id: string | null; due_at: string | null; created_at: string; updated_at: string };
        Insert: { project_id: string; title: string; description?: string | null; priority?: string; severity?: string; status_id?: string | null; assignee?: string | null };
        Update: { title?: string; description?: string | null; status_id?: string | null; assignee?: string | null; priority?: string };
      };
      statuses: {
        Row: { id: string; name: string; category: string; created_at: string; updated_at: string };
        Insert: { name: string; category: string };
        Update: { name?: string; category?: string };
      };
    };
  };
}
