import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Profile } from "@/contexts/AuthContext";

export function useProfiles(search?: string) {
  const { toast } = useToast();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let q = supabase
        .from("profiles")
        .select("id, email, full_name, avatar_url, org_id, role, status, created_at, updated_at")
        .order("created_at", { ascending: false });

      if (search?.trim()) {
        q = q.or(`email.ilike.%${search}%,full_name.ilike.%${search}%`);
      }

      const { data, error: err } = await q;
      if (err) throw err;
      setProfiles((data ?? []) as Profile[]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Failed to load users";
      setError(msg);
      toast({ title: "Error", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [search, toast]);

  useEffect(() => { load(); }, [load]);

  const updateRole = useCallback(async (userId: string, role: Profile["role"]) => {
    const { error: err } = await supabase
      .from("profiles")
      .update({ role })
      .eq("id", userId);
    if (err) { toast({ title: "Error", description: err.message, variant: "destructive" }); throw err; }
    setProfiles(prev => prev.map(p => p.id === userId ? { ...p, role } : p));
    toast({ title: "Role updated" });
  }, [toast]);

  const updateStatus = useCallback(async (userId: string, status: Profile["status"]) => {
    const { error: err } = await supabase
      .from("profiles")
      .update({ status })
      .eq("id", userId);
    if (err) { toast({ title: "Error", description: err.message, variant: "destructive" }); throw err; }
    setProfiles(prev => prev.map(p => p.id === userId ? { ...p, status } : p));
    toast({ title: "Status updated" });
  }, [toast]);

  const inviteUser = useCallback(async (email: string, role: string = "user") => {
    const { error: err } = await supabase
      .from("invites")
      .insert({ email, role });
    if (err) { toast({ title: "Error sending invite", description: err.message, variant: "destructive" }); throw err; }
    toast({ title: "Invite sent", description: `Invitation sent to ${email}` });
  }, [toast]);

  return { profiles, loading, error, updateRole, updateStatus, inviteUser, reload: load };
}
