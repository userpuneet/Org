import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export type EventType = "meeting" | "maintenance" | "deadline" | "reminder" | "other";
export type EventPriority = "low" | "medium" | "high";

export interface CalendarEvent {
  id: string;
  title: string;
  description: string | null;
  event_type: EventType;
  priority: EventPriority;
  starts_at: string;
  ends_at: string;
  all_day: boolean;
  created_at: string;
}

export function useCalendarEvents(month?: Date) {
  const { toast } = useToast();
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let q = supabase
        .from("calendar_events")
        .select("id, title, description, event_type, priority, starts_at, ends_at, all_day, created_at")
        .order("starts_at", { ascending: true });

      if (month) {
        const start = new Date(month.getFullYear(), month.getMonth(), 1).toISOString();
        const end   = new Date(month.getFullYear(), month.getMonth() + 1, 0, 23, 59, 59).toISOString();
        q = q.gte("starts_at", start).lte("starts_at", end);
      }

      const { data, error: err } = await q;
      if (err) throw err;
      setEvents((data ?? []) as CalendarEvent[]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Failed to load calendar events";
      setError(msg);
      toast({ title: "Error", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [month, toast]);

  useEffect(() => { load(); }, [load]);

  const create = useCallback(async (payload: {
    title: string;
    description?: string;
    event_type: EventType;
    priority?: EventPriority;
    starts_at: string;
    ends_at: string;
    all_day?: boolean;
  }) => {
    const { data, error: err } = await supabase
      .from("calendar_events")
      .insert(payload)
      .select()
      .maybeSingle();
    if (err) { toast({ title: "Error", description: err.message, variant: "destructive" }); throw err; }
    if (data) {
      setEvents(prev => [...prev, data as CalendarEvent].sort(
        (a, b) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime()
      ));
      toast({ title: "Event created" });
    }
    return data as CalendarEvent;
  }, [toast]);

  const remove = useCallback(async (id: string) => {
    const { error: err } = await supabase.from("calendar_events").delete().eq("id", id);
    if (err) { toast({ title: "Error", description: err.message, variant: "destructive" }); throw err; }
    setEvents(prev => prev.filter(e => e.id !== id));
    toast({ title: "Event deleted" });
  }, [toast]);

  return { events, loading, error, create, remove, reload: load };
}
