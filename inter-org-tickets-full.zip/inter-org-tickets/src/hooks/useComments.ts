import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import type { Comment } from "@/types/threads";

type DBComment = {
  id: string;
  thread_id: string | null;
  issue_id: string | null;
  author_id: string | null;
  author_name: string | null;
  author_org: string | null;
  content: string;
  is_internal: boolean;
  reply_to_id: string | null;
  category: string | null;
  is_edited: boolean;
  edited_at: string | null;
  created_at: string;
};

function dbToComment(r: DBComment): Comment {
  return {
    id: r.id,
    author: r.author_name ?? "Unknown",
    authorOrg: r.author_org ?? "",
    content: r.content,
    timestamp: r.created_at,
    isInternal: r.is_internal,
    replyTo: r.reply_to_id ?? undefined,
    category: (r.category as Comment["category"]) ?? undefined,
    isEdited: r.is_edited,
  };
}

export function useComments(threadId?: string, issueId?: string) {
  const { toast } = useToast();
  const { profile } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!threadId && !issueId) { setLoading(false); return; }
    setLoading(true);
    let q = supabase
      .from("comments")
      .select("id, thread_id, issue_id, author_id, author_name, author_org, content, is_internal, reply_to_id, category, is_edited, edited_at, created_at")
      .order("created_at", { ascending: true });

    if (threadId) q = q.eq("thread_id", threadId);
    else if (issueId) q = q.eq("issue_id", issueId);

    const { data, error } = await q;
    if (error) { toast({ title: "Error loading comments", description: error.message, variant: "destructive" }); }
    else setComments((data ?? []).map(r => dbToComment(r as DBComment)));
    setLoading(false);
  }, [threadId, issueId, toast]);

  useEffect(() => { load(); }, [load]);

  const post = useCallback(async (payload: {
    content: string;
    is_internal?: boolean;
    reply_to_id?: string | null;
    category?: string | null;
  }) => {
    const insert: Record<string, unknown> = {
      content: payload.content,
      is_internal: payload.is_internal ?? false,
      reply_to_id: payload.reply_to_id ?? null,
      category: payload.category ?? null,
      author_id: profile?.id ?? null,
      author_name: profile?.full_name ?? profile?.email ?? "Unknown",
      author_org: null,
    };
    if (threadId) insert.thread_id = threadId;
    else if (issueId) insert.issue_id = issueId;

    const { data, error: err } = await supabase
      .from("comments")
      .insert(insert)
      .select()
      .maybeSingle();
    if (err) { toast({ title: "Error posting comment", description: err.message, variant: "destructive" }); throw err; }
    if (data) setComments(prev => [...prev, dbToComment(data as DBComment)]);
  }, [threadId, issueId, profile, toast]);

  const edit = useCallback(async (id: string, content: string) => {
    const { error: err } = await supabase
      .from("comments")
      .update({ content, is_edited: true, edited_at: new Date().toISOString() })
      .eq("id", id);
    if (err) { toast({ title: "Error editing comment", description: err.message, variant: "destructive" }); throw err; }
    setComments(prev => prev.map(c => c.id === id ? { ...c, content, isEdited: true } : c));
    toast({ title: "Comment updated" });
  }, [toast]);

  const remove = useCallback(async (id: string) => {
    const { error: err } = await supabase.from("comments").delete().eq("id", id);
    if (err) { toast({ title: "Error deleting comment", description: err.message, variant: "destructive" }); throw err; }
    setComments(prev => prev.filter(c => c.id !== id));
    toast({ title: "Comment deleted" });
  }, [toast]);

  return { comments, loading, post, edit, remove, reload: load };
}
