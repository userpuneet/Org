import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface SLAPolicy {
  id: string;
  name: string;
  description: string | null;
  priority: "low" | "medium" | "high" | "critical";
  first_response_hours: number;
  resolution_hours: number;
  is_active: boolean;
  created_at: string;
}

export function useSLAPolicies() {
  const { toast } = useToast();
  const [policies, setPolicies] = useState<SLAPolicy[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("sla_policies")
      .select("*")
      .order("priority", { ascending: false });
    if (error) toast({ title: "Error loading SLA policies", description: error.message, variant: "destructive" });
    else setPolicies((data ?? []) as SLAPolicy[]);
    setLoading(false);
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const create = useCallback(async (payload: Omit<SLAPolicy, "id" | "created_at">) => {
    const { data, error } = await supabase.from("sla_policies").insert(payload).select().maybeSingle();
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); throw error; }
    if (data) { setPolicies(prev => [...prev, data as SLAPolicy]); toast({ title: "Policy created" }); }
  }, [toast]);

  const update = useCallback(async (id: string, payload: Partial<SLAPolicy>) => {
    const { error } = await supabase.from("sla_policies").update(payload).eq("id", id);
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); throw error; }
    setPolicies(prev => prev.map(p => p.id === id ? { ...p, ...payload } : p));
    toast({ title: "Policy updated" });
  }, [toast]);

  const remove = useCallback(async (id: string) => {
    const { error } = await supabase.from("sla_policies").delete().eq("id", id);
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); throw error; }
    setPolicies(prev => prev.filter(p => p.id !== id));
    toast({ title: "Policy deleted" });
  }, [toast]);

  // Check which threads are breaching SLA
  const checkBreaches = useCallback(async () => {
    const now = new Date();
    const { data: threads } = await supabase
      .from("threads")
      .select("id, priority, status, created_at, updated_at, external_id, title")
      .in("status", ["open", "in_progress"]);

    const breaches: { threadId: string; title: string; type: "response" | "resolution"; hoursOverdue: number }[] = [];

    for (const thread of (threads ?? [])) {
      const policy = policies.find(p => p.priority === thread.priority && p.is_active);
      if (!policy) continue;
      const created = new Date(thread.created_at);
      const ageHours = (now.getTime() - created.getTime()) / (1000 * 60 * 60);
      if (ageHours > policy.resolution_hours) {
        breaches.push({ threadId: thread.id, title: thread.title, type: "resolution", hoursOverdue: Math.round(ageHours - policy.resolution_hours) });
      } else if (ageHours > policy.first_response_hours) {
        breaches.push({ threadId: thread.id, title: thread.title, type: "response", hoursOverdue: Math.round(ageHours - policy.first_response_hours) });
      }
    }
    return breaches;
  }, [policies]);

  return { policies, loading, create, update, remove, checkBreaches, reload: load };
}
