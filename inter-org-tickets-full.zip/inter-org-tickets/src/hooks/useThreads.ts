import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Thread, ThreadStatus, ThreadPriority } from "@/types/threads";

type DBThread = {
  id: string;
  external_id: string | null;
  title: string;
  description: string | null;
  status: string;
  priority: string;
  relationship_type: string;
  assignee_id: string | null;
  raiser_id: string | null;
  eta_value: string | null;
  eta_unit: string | null;
  eta_set_at: string | null;
  created_at: string;
  updated_at: string;
  raiser: { id: string; full_name: string | null; email: string } | null;
  assignee: { id: string; full_name: string | null; email: string } | null;
};

function dbToThread(r: DBThread): Thread {
  return {
    id: r.external_id ?? r.id.slice(0, 8).toUpperCase(),
    _uuid: r.id,
    title: r.title,
    organization: r.raiser?.email?.split("@")[1] ?? "Unknown",
    status: r.status as ThreadStatus,
    priority: r.priority as ThreadPriority,
    created: r.created_at,
    updated: r.updated_at,
    responseTime: "—",
    assignee: r.assignee?.full_name ?? r.assignee?.email ?? null,
    description: r.description ?? undefined,
    raiser: {
      name: r.raiser?.full_name ?? r.raiser?.email ?? "Unknown",
      email: r.raiser?.email ?? "",
      organization: r.raiser?.email?.split("@")[1] ?? "",
    },
    recipient: {
      name: r.assignee?.full_name ?? "Unassigned",
      email: r.assignee?.email ?? "",
      organization: "Support Team",
    },
    relationshipType: r.relationship_type as Thread["relationshipType"],
    eta: r.eta_value ? {
      value: `${r.eta_value} ${r.eta_unit ?? ""}`.trim(),
      setBy: "system",
      setByOrg: "",
      timestamp: r.eta_set_at ?? r.updated_at,
    } : undefined,
  };
}

export interface UseThreadsReturn {
  threads: Thread[];
  loading: boolean;
  error: string | null;
  updateStatus: (threadUuid: string, status: ThreadStatus) => void;
  updatePriority: (threadUuid: string, priority: ThreadPriority) => void;
  updateAssignee: (threadUuid: string, assignee: string | null) => void;
  reload: () => void;
}

export function useThreads(): UseThreadsReturn {
  const { toast } = useToast();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: err } = await supabase
        .from("threads")
        .select(`
          id, external_id, title, description, status, priority, relationship_type,
          assignee_id, raiser_id, eta_value, eta_unit, eta_set_at, created_at, updated_at,
          raiser:raiser_id ( id, full_name, email ),
          assignee:assignee_id ( id, full_name, email )
        `)
        .order("updated_at", { ascending: false })
        .limit(200);

      if (err) throw err;
      setThreads((data as unknown as DBThread[]).map(dbToThread));
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : "Failed to load threads.";
      setError(message);
      toast({ title: "Error loading threads", description: message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  // Persist status update to DB
  const updateStatus = useCallback(async (threadId: string, status: ThreadStatus) => {
    // threadId here is external_id; find uuid
    const thread = threads.find(t => t.id === threadId);
    const uuid = (thread as any)?._uuid ?? threadId;
    await supabase.from("threads").update({ status }).eq("id", uuid);
    setThreads(prev => prev.map(t => t.id === threadId ? { ...t, status } : t));
  }, [threads]);

  const updatePriority = useCallback(async (threadId: string, priority: ThreadPriority) => {
    const thread = threads.find(t => t.id === threadId);
    const uuid = (thread as any)?._uuid ?? threadId;
    await supabase.from("threads").update({ priority }).eq("id", uuid);
    setThreads(prev => prev.map(t => t.id === threadId ? { ...t, priority } : t));
  }, [threads]);

  const updateAssignee = useCallback(async (threadId: string, assignee: string | null) => {
    setThreads(prev => prev.map(t => t.id === threadId ? { ...t, assignee } : t));
  }, []);

  return { threads, loading, error, updateStatus, updatePriority, updateAssignee, reload: load };
}
