import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export type AnnouncementCategory = "system" | "maintenance" | "feature" | "security" | "other";

export interface Announcement {
  id: string;
  title: string;
  content: string;
  category: AnnouncementCategory;
  is_important: boolean;
  published_at: string;
  expires_at: string | null;
  created_at: string;
}

export function useAnnouncements(category?: AnnouncementCategory) {
  const { toast } = useToast();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let q = supabase
        .from("announcements")
        .select("id, title, content, category, is_important, published_at, expires_at, created_at")
        .order("published_at", { ascending: false });
      if (category) q = q.eq("category", category);

      const { data, error: err } = await q;
      if (err) throw err;
      setAnnouncements((data ?? []) as Announcement[]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Failed to load announcements";
      setError(msg);
      toast({ title: "Error", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [category, toast]);

  useEffect(() => { load(); }, [load]);

  const create = useCallback(async (payload: {
    title: string; content: string; category: AnnouncementCategory; is_important?: boolean;
  }) => {
    const { data, error: err } = await supabase
      .from("announcements")
      .insert(payload)
      .select()
      .maybeSingle();
    if (err) { toast({ title: "Error", description: err.message, variant: "destructive" }); throw err; }
    if (data) {
      setAnnouncements(prev => [data as Announcement, ...prev]);
      toast({ title: "Announcement posted" });
    }
  }, [toast]);

  return { announcements, loading, error, create, reload: load };
}
