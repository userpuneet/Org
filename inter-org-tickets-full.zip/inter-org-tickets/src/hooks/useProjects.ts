import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface Project {
  id: string;
  key: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
  issue_count?: number;
  completed_count?: number;
}

export function useProjects() {
  const { toast } = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: projs, error: err } = await supabase
        .from("projects")
        .select("id, key, name, description, created_at, updated_at")
        .order("updated_at", { ascending: false });
      if (err) throw err;

      // For each project, get issue counts
      const withCounts = await Promise.all((projs ?? []).map(async (p) => {
        const [totalRes, doneRes] = await Promise.all([
          supabase.from("issues").select("id", { count: "exact", head: true }).eq("project_id", p.id),
          supabase.from("issues").select("id", { count: "exact", head: true })
            .eq("project_id", p.id)
            .in("status_id", (await supabase.from("statuses").select("id").eq("category", "done")).data?.map(s => s.id) ?? [])
        ]);
        return {
          ...p,
          issue_count: totalRes.count ?? 0,
          completed_count: doneRes.count ?? 0,
        } as Project;
      }));

      setProjects(withCounts);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Failed to load projects";
      setError(msg);
      toast({ title: "Error", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const create = useCallback(async (payload: { name: string; key: string; description?: string }) => {
    const { data, error: err } = await supabase
      .from("projects")
      .insert(payload)
      .select()
      .maybeSingle();
    if (err) { toast({ title: "Error creating project", description: err.message, variant: "destructive" }); throw err; }
    toast({ title: "Project created", description: payload.name });
    await load();
    return data;
  }, [toast, load]);

  return { projects, loading, error, create, reload: load };
}
